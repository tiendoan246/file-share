import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Book from "./book"
import Magazine from "./magazine"
import Layout from "./Layout";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="books" element={<Book />} />
          <Route path="magazines" element={<Magazine />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
