import React, { useState } from "react";
import ServerSimpleTableComponent from "./components/server-simple-table";
const columns = [
  {
    field: "title",
    headerName: "title",
  },
  {
    field: "description",
    headerName: "description",
  },
  {
    field: "isbn",
    headerName: "isbn",
  }
];

function Book() {
  const [list, setList] = useState([]);

  const tableData = (item) => {

    fetch('http://localhost:9090/books', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'
      },
      body: JSON.stringify({
        filter: null,
        page: {
          limit: 50,
          offset: 0
        },
        sort: {
          sortBy: [
            'title'
          ],
          order: 'asc'
        }
      })
    })
    .then((response) => response.json())
    .then((json) => setList(json));
  };

  return (
    <div className="App">
      <ServerSimpleTableComponent
        columns={columns}
        list={list}
        onGetData={tableData}
        total={1000}
      />
    </div>
  );
}

export default Book;
