# project structure & framework
- spring boot
- spring data jpa connect to Postgresql
- lombok for data, request, .. classes
- resilience4j for rate limiter
- query-builder for rapid development with search API: https://github.com/tiendoan246/jpa-query-builder

# init database
run script from resources/static/init.sql

# API endpoint
- /authors
- /books
- /magazines

# api search request structure support
- filter: support dynamic filter with a lot of combination and group
- page: support paging parameters
- sort: support multiple sorting parameters

# filter logic
Sample for: Find books by author. Given an author, find all the books of that author (pagination is not required)
```shell
    {
        "filter": {
            "authorEntities": {
                "email": {
                    "eq": "author1@gmail.com"
                }
            }
        }
    }
```
