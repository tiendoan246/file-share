-- CREATE AUTHORS
INSERT INTO public.authors
(resource_id, email, first_name, surname, created_at, updated_at)
VALUES('0b459cba-3558-4996-9c63-857f9bae4f37', 'author1@gmail.com', 'john', '1', '2024-07-02 13:18:41.478', NULL);
INSERT INTO public.authors
(resource_id, email, first_name, surname, created_at, updated_at)
VALUES('c183b355-77cb-42a3-9d8b-93caa3c229bf', 'author2@gmail.com', 'david', '1', '2024-07-02 13:19:12.608', NULL);
INSERT INTO public.authors
(resource_id, email, first_name, surname, created_at, updated_at)
VALUES('33a0f6dd-6cf7-4b45-9d7a-cb649108695f', 'author3@gmail.com', 'tom', '1', '2024-07-02 13:19:12.608', NULL);

-- CREATE BOOKS
INSERT INTO public.books
(resource_id, title, short_description, isbn, created_at, updated_at)
VALUES('28bc7878-2439-4539-b6a4-ff694fbcc89e', 'Book 1', 'Sample book 1', 'B-939844', '2024-07-02 13:32:45.657', NULL);
INSERT INTO public.books
(resource_id, title, short_description, isbn, created_at, updated_at)
VALUES('f7ecd54c-36e8-427a-a6a1-7ecbe1e29d6c', 'Book 2', 'Sample book 2', 'B-343423', '2024-07-02 13:32:45.657', NULL);
INSERT INTO public.books
(resource_id, title, short_description, isbn, created_at, updated_at)
VALUES('d924acd8-79af-40e6-85b4-51aa50247420', 'Book 3', 'Sample book 3', 'B-334222', '2024-07-02 13:32:45.657', NULL);

-- CREATE BOOK-AUTHOR
INSERT INTO public.book_authors
(resource_id, book_resource_id, author_resource_id)
VALUES(gen_random_uuid(), '28bc7878-2439-4539-b6a4-ff694fbcc89e', '0b459cba-3558-4996-9c63-857f9bae4f37');
INSERT INTO public.book_authors
(resource_id, book_resource_id, author_resource_id)
VALUES(gen_random_uuid(), '28bc7878-2439-4539-b6a4-ff694fbcc89e', 'c183b355-77cb-42a3-9d8b-93caa3c229bf');
INSERT INTO public.book_authors
(resource_id, book_resource_id, author_resource_id)
VALUES(gen_random_uuid(), 'f7ecd54c-36e8-427a-a6a1-7ecbe1e29d6c', '33a0f6dd-6cf7-4b45-9d7a-cb649108695f');

-- CREATE MAGAZINE
INSERT INTO public.magazines
(resource_id, title, publish_date, isbn, created_at, updated_at)
VALUES('1c70f5f8-5e59-42ef-bb31-0159e78d9355', 'Magazine 1', '2024-04-01 10:19:06.940', 'M-983434', '2024-07-02 13:42:37.410', NULL);
INSERT INTO public.magazines
(resource_id, title, publish_date, isbn, created_at, updated_at)
VALUES('79149941-6c56-42dd-87e2-8ebd102a21e3', 'Magazine 2', '2024-01-01 10:19:06.940', 'M-343242', '2024-07-02 13:42:37.410', NULL);
INSERT INTO public.magazines
(resource_id, title, publish_date, isbn, created_at, updated_at)
VALUES('23fcca65-8fb9-4ddd-be9b-cc4f5d800ff1', 'Magazine 3', '2024-07-01 10:19:06.940', 'M-221233', '2024-07-02 13:42:37.410', NULL);

-- CREATE MAGAZINE AUTHOR
INSERT INTO public.magazine_authors
(resource_id, magazine_resource_id, author_resource_id)
VALUES(gen_random_uuid(), '1c70f5f8-5e59-42ef-bb31-0159e78d9355', '0b459cba-3558-4996-9c63-857f9bae4f37');
INSERT INTO public.magazine_authors
(resource_id, magazine_resource_id, author_resource_id)
VALUES(gen_random_uuid(), '1c70f5f8-5e59-42ef-bb31-0159e78d9355', '33a0f6dd-6cf7-4b45-9d7a-cb649108695f');
INSERT INTO public.magazine_authors
(resource_id, magazine_resource_id, author_resource_id)
VALUES(gen_random_uuid(), '23fcca65-8fb9-4ddd-be9b-cc4f5d800ff1', 'c183b355-77cb-42a3-9d8b-93caa3c229bf');