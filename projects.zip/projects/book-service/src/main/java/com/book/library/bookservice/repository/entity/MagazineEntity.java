package com.book.library.bookservice.repository.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.util.List;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "magazines")
public class MagazineEntity extends BaseEntity {
    @Id
    @Column(name = "resource_id")
    private String resourceId;

    @Column(name = "title")
    private String title;

    @Column(name = "publish_date")
    private Timestamp publishDate;

    @Column(name = "isbn")
    private String isbn;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "magazine_authors",
            joinColumns = @JoinColumn(name = "magazine_resource_id"),
            inverseJoinColumns = @JoinColumn(name = "author_resource_id"))
    private List<AuthorEntity> authorEntities;
}
