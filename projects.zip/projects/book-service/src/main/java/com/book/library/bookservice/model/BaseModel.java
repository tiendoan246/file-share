package com.book.library.bookservice.model;

public class BaseModel {
}
