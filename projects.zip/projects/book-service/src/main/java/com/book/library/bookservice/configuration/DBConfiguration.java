package com.book.library.bookservice.configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.Properties;

@Configuration
@EnableJpaRepositories(basePackages = "com.book.library.bookservice")
@EnableTransactionManagement
public class DBConfiguration {

    @Value("${book.datasource.postgres.writer.url}")
    private String dbUrl;

    @Value("${book.datasource.postgres.writer.driverClassName}")
    private String dbDriver;

    @Value("${book.datasource.postgres.writer.username}")
    private String userName;

    @Value("${book.datasource.postgres.writer.password}")
    private String password;

    @Value("${book.datasource.postgres.writer.hikari.connection-timeout}")
    private int connectionTimeOut;

    @Value("${book.datasource.postgres.writer.hikari.minimum-idle}")
    private int minIdle;

    @Value("${book.datasource.postgres.writer.hikari.maximum-pool-size}")
    private int maxPoolSize;

    @Value("${book.datasource.postgres.writer.hikari.idle-timeout}")
    private int idleTimeOut;

    @Value("${book.datasource.postgres.writer.hikari.max-lifetime}")
    private int maxLifeTime;
    
    @Value("${book.datasource.postgres.reader.url}")
    private String roDbUrl;

    @Value("${book.datasource.postgres.reader.driverClassName}")
    private String roDbDriver;

    @Value("${book.datasource.postgres.reader.username}")
    private String roUserName;

    @Value("${book.datasource.postgres.reader.password}")
    private String roPassword;

    @Value("${book.datasource.postgres.reader.hikari.connection-timeout}")
    private int roConnectionTimeOut;

    @Value("${book.datasource.postgres.reader.hikari.minimum-idle}")
    private int roMinIdle;

    @Value("${book.datasource.postgres.reader.hikari.maximum-pool-size}")
    private int roMaxPoolSize;

    @Value("${book.datasource.postgres.reader.hikari.idle-timeout}")
    private int roIdleTimeOut;

    @Value("${book.datasource.postgres.reader.hikari.max-lifetime}")
    private int roMaxLifeTime;

    @Value("${spring.datasource.database-platform}")
    private String databasePlatform;


    @Bean
    public HikariDataSource getHikariDataSourceForRead() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(roDbUrl);
        hikariConfig.setUsername(roUserName);
        hikariConfig.setPassword(roPassword);
        addCommonPropertiesForReader(hikariConfig);
        return new HikariDataSource(hikariConfig);
    }

    @Bean
    public HikariDataSource getHikariDataSourceForWrite() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(dbUrl);
        hikariConfig.setUsername(userName);
        hikariConfig.setPassword(password);
        addCommonPropertiesForWriter(hikariConfig);
        return new HikariDataSource(hikariConfig);
    }

    private void addCommonPropertiesForWriter(HikariConfig config) {
        config.setConnectionTimeout(connectionTimeOut);
        config.setMinimumIdle(minIdle);
        config.setMaximumPoolSize(maxPoolSize);
        config.setDriverClassName(dbDriver);
        config.setAutoCommit(false);
    }

    private void addCommonPropertiesForReader(HikariConfig config) {
        config.setConnectionTimeout(roConnectionTimeOut);
        config.setMinimumIdle(roMinIdle);
        config.setMaximumPoolSize(roMaxPoolSize);
        config.setDriverClassName(dbDriver);
        config.setAutoCommit(false);
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(getHikariDataSourceForWrite());
        em.setPackagesToScan(new String[] { "com.book.library.bookservice" });
        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());
        return em;
    }

    private Properties additionalProperties() {
        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", databasePlatform);
        properties.setProperty("hibernate.connection.provider_disables_autocommit", "true");
        return properties;
    }

}