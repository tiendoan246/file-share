package com.book.library.bookservice.controller;

import com.book.library.bookservice.model.request.SearchAuthorRequest;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.service.SearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/authors")
@RequiredArgsConstructor
public class AuthorController {

    private final SearchService<SearchAuthorRequest> searchService;

    @PostMapping("/query")
    public BasePageableResponse searchAuthors(@RequestBody SearchAuthorRequest request) {
        return searchService.search(request);
    }
}
