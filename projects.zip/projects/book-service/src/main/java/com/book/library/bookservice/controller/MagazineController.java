package com.book.library.bookservice.controller;

import com.book.library.bookservice.model.request.SearchMagazineRequest;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.service.SearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/magazines")
@RequiredArgsConstructor
public class MagazineController {

    private final SearchService<SearchMagazineRequest> searchService;

    @PostMapping("/query")
    public BasePageableResponse searchMagazines(SearchMagazineRequest request) {
        return searchService.search(request);
    }
}
