package com.book.library.bookservice.repository.maper;

import com.book.library.bookservice.model.response.AuthorResponse;
import com.book.library.bookservice.model.response.MagazineResponse;
import com.book.library.bookservice.repository.entity.MagazineEntity;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
public class MagazineMapper {

    public static List<MagazineResponse> toMagazineResponses(List<MagazineEntity> entities) {
        return entities.stream()
                .map(MagazineMapper::toMagazineResponse)
                .collect(Collectors.toList());
    }

    public static MagazineResponse toMagazineResponse(MagazineEntity entity) {
        List<AuthorResponse> authors = Optional.ofNullable(entity.getAuthorEntities())
                .map(AuthorMapper::toAuthorResponses)
                .orElse(Collections.emptyList());

        return MagazineResponse.builder()
                .resourceId(entity.getResourceId())
                .title(entity.getTitle())
                .publishDate(entity.getPublishDate())
                .isbn(entity.getIsbn())
                .authors(authors)
                .build();
    }
}
