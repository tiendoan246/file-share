package com.book.library.bookservice.repository.maper;

import com.book.library.bookservice.model.response.AuthorResponse;
import com.book.library.bookservice.model.response.BookResponse;
import com.book.library.bookservice.repository.entity.BookEntity;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
public class BookMapper {

    public static List<BookResponse> toBookResponses(List<BookEntity> entities) {
        return entities.stream()
                .map(BookMapper::toBookResponse)
                .collect(Collectors.toList());
    }

    public static BookResponse toBookResponse(BookEntity entity) {
        List<AuthorResponse> authors = Optional.ofNullable(entity.getAuthorEntities())
                .map(AuthorMapper::toAuthorResponses)
                .orElse(Collections.emptyList());

        return BookResponse.builder()
                .resourceId(entity.getResourceId())
                .shortDescription(entity.getShortDescription())
                .isbn(entity.getIsbn())
                .authors(authors)
                .build();
    }
}
