package com.book.library.bookservice.service.impl;

import com.book.library.bookservice.model.request.SearchAuthorRequest;
import com.book.library.bookservice.model.response.AuthorResponse;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.repository.AuthorRepository;
import com.book.library.bookservice.repository.entity.AuthorEntity;
import com.book.library.bookservice.repository.maper.AuthorMapper;
import com.book.library.bookservice.service.SearchService;
import com.query.querybuilder.builder.QueryBuilder;
import com.query.querybuilder.utils.SearchQueryBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthorServiceImpl implements SearchService<SearchAuthorRequest> {

    private final AuthorRepository authorRepository;
    private final List<QueryBuilder<AuthorEntity>> queryBuilders;

    @Override
    public BasePageableResponse search(SearchAuthorRequest request) {
        log.info("=== SEARCH AUTHOR REQUEST: === " + request.toString());

        Pair<Specification<AuthorEntity>, Pageable> searchQueryBuilder = SearchQueryBuilder.builder(this.queryBuilders)
                .withData(request.getFilter())
                .withPage(request.getPage())
                .withSort(request.getSort())
                .build();

        Page<AuthorEntity> page = this.authorRepository.findAll(searchQueryBuilder.getLeft(), searchQueryBuilder.getRight());

        List<AuthorResponse> authors = Optional.ofNullable(page.getContent())
                .map(items -> AuthorMapper.toAuthorResponses(items))
                .orElse(Collections.emptyList());

        return BasePageableResponse.getInstance(authors, page.getTotalElements(), page.getTotalPages());
    }
}
