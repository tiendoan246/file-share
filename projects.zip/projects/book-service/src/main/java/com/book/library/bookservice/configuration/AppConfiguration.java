package com.book.library.bookservice.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfiguration {


}
