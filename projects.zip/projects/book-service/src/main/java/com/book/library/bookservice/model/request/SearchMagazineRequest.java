package com.book.library.bookservice.model.request;

import com.book.library.bookservice.model.request.filter.MagazineFilter;
import com.query.querybuilder.filter.PageFilter;
import com.query.querybuilder.filter.SortFilter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchMagazineRequest {
    private MagazineFilter filter;
    private PageFilter page;
    private SortFilter sort;
}
