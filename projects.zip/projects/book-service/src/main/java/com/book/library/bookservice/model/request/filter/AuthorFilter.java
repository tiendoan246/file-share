package com.book.library.bookservice.model.request.filter;

import com.query.querybuilder.expression.DateExpression;
import com.query.querybuilder.expression.StringExpression;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthorFilter {

    private StringExpression resourceId;
    private StringExpression email;
    private StringExpression firstName;
    private StringExpression surname;
    private DateExpression createdAt;
    private DateExpression updatedAt;

    private AuthorFilter and;
    private AuthorFilter or;
}
