package com.book.library.bookservice.model.request.filter;

import com.query.querybuilder.expression.DateExpression;
import com.query.querybuilder.expression.StringExpression;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MagazineFilter {

    private StringExpression resourceId;
    private StringExpression title;
    private DateExpression publishDate;
    private StringExpression isbn;
    private DateExpression createdAt;
    private DateExpression updatedAt;
    private AuthorFilter authorEntities;

    private MagazineFilter and;
    private MagazineFilter or;
}
