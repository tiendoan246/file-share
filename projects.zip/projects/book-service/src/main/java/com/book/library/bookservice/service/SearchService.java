package com.book.library.bookservice.service;

import com.book.library.bookservice.model.response.BasePageableResponse;

public interface SearchService<T> {
    BasePageableResponse search(T request);
}
