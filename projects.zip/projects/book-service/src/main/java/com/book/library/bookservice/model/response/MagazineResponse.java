package com.book.library.bookservice.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MagazineResponse {
    private String resourceId;
    private String title;
    private Timestamp publishDate;
    private String isbn;
    private List<AuthorResponse> authors;
}
