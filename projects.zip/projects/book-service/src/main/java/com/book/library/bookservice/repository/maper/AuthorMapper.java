package com.book.library.bookservice.repository.maper;

import com.book.library.bookservice.model.response.AuthorResponse;
import com.book.library.bookservice.repository.entity.AuthorEntity;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class AuthorMapper {

    public static List<AuthorResponse> toAuthorResponses(List<AuthorEntity> entities) {
        return entities.stream()
                .map(AuthorMapper::toAuthorResponse)
                .collect(Collectors.toList());
    }

    public static AuthorResponse toAuthorResponse(AuthorEntity entity) {
        return AuthorResponse.builder()
                .resourceId(entity.getResourceId())
                .email(entity.getEmail())
                .firstName(entity.getFirstName())
                .surname(entity.getSurname())
                .build();
    }
}
