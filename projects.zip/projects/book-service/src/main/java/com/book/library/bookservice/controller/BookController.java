package com.book.library.bookservice.controller;

import com.book.library.bookservice.model.request.SearchBookRequest;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.service.SearchService;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
@RateLimiter(name = "timeLimiterApi")
public class BookController {

    private final SearchService<SearchBookRequest> searchService;

    @PostMapping("/query")
    public BasePageableResponse searchAuthors(@RequestBody SearchBookRequest request) {
        return searchService.search(request);
    }
}
