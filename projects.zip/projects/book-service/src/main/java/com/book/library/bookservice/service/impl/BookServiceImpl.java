package com.book.library.bookservice.service.impl;

import com.book.library.bookservice.model.request.SearchBookRequest;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.model.response.BookResponse;
import com.book.library.bookservice.repository.BookRepository;
import com.book.library.bookservice.repository.entity.BookEntity;
import com.book.library.bookservice.repository.maper.BookMapper;
import com.book.library.bookservice.service.SearchService;
import com.query.querybuilder.builder.QueryBuilder;
import com.query.querybuilder.utils.SearchQueryBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookServiceImpl implements SearchService<SearchBookRequest> {

    private final BookRepository bookRepository;
    private final List<QueryBuilder<BookEntity>> queryBuilders;

    @Override
    @Transactional(readOnly = true)
    public BasePageableResponse search(SearchBookRequest request) {
        log.info("=== SEARCH BOOK REQUEST: === " + request.toString());

        Pair<Specification<BookEntity>, Pageable> searchQueryBuilder = SearchQueryBuilder.builder(this.queryBuilders)
                .withData(request.getFilter())
                .withPage(request.getPage())
                .withSort(request.getSort())
                .build();

        Page<BookEntity> page = this.bookRepository.findAll(searchQueryBuilder.getLeft(), searchQueryBuilder.getRight());

        List<BookResponse> books = Optional.ofNullable(page.getContent())
                .map(items -> BookMapper.toBookResponses(items))
                .orElse(Collections.emptyList());

        return BasePageableResponse.getInstance(books, page.getTotalElements(), page.getTotalPages());
    }
}
