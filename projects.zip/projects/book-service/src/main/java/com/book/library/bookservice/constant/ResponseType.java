package com.book.library.bookservice.constant;

public enum ResponseType {
    SUCCESS,
    FAILURE;
}
