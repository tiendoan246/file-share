package com.book.library.bookservice.service.impl;

import com.book.library.bookservice.model.request.SearchMagazineRequest;
import com.book.library.bookservice.model.response.BasePageableResponse;
import com.book.library.bookservice.model.response.MagazineResponse;
import com.book.library.bookservice.repository.MagazineRepository;
import com.book.library.bookservice.repository.entity.MagazineEntity;
import com.book.library.bookservice.repository.maper.MagazineMapper;
import com.book.library.bookservice.service.SearchService;
import com.query.querybuilder.builder.QueryBuilder;
import com.query.querybuilder.utils.SearchQueryBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class MagazineServiceImpl implements SearchService<SearchMagazineRequest> {

    private final MagazineRepository magazineRepository;
    private final List<QueryBuilder<MagazineEntity>> queryBuilders;

    @Override
    public BasePageableResponse search(SearchMagazineRequest request) {
        log.info("=== SEARCH MAGAZINE REQUEST: === " + request.toString());

        Pair<Specification<MagazineEntity>, Pageable> searchQueryBuilder = SearchQueryBuilder.builder(this.queryBuilders)
                .withData(request.getFilter())
                .withPage(request.getPage())
                .withSort(request.getSort())
                .build();

        Page<MagazineEntity> page = this.magazineRepository.findAll(searchQueryBuilder.getLeft(), searchQueryBuilder.getRight());

        List<MagazineResponse> magazines = Optional.ofNullable(page.getContent())
                .map(items -> MagazineMapper.toMagazineResponses(items))
                .orElse(Collections.emptyList());

        return BasePageableResponse.getInstance(magazines, page.getTotalElements(), page.getTotalPages());
    }
}
