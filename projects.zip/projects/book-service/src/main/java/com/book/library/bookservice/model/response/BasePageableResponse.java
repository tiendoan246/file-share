package com.book.library.bookservice.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BasePageableResponse<T> {
    private T data;
    private long totalElements;
    private int totalPages;

    private BasePageableResponse(T data) {
        this.data = data;
    }

    private BasePageableResponse(T data, long totalElements, int totalPages) {
        this.data = data;
        this.totalElements = totalElements;
        this.totalPages = totalPages;
    }

    public static <T> BasePageableResponse getInstance(T data, long totalElements, int totalPages) {
        return new BasePageableResponse<T>(data, totalElements, totalPages);
    }
}
